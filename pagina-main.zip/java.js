alert("hola mundo")
alert("Bienvenido al curso de Programacion1")